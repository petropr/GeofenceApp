package com.example.alexis.geofenceapp;

public class ListsPoi {
    //private static final String TAG ="LIstPoi";

    public String name;

    public double latitude;
    public double longtitude;
    public void insert(String nam,double lat,double longe){
        name=nam;
        latitude=lat;
        longtitude=longe;
    }
}
